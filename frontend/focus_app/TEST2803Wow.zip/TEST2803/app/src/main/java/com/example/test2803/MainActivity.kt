package com.example.test2803

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var messageTextView: TextView

    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        messageTextView = findViewById(R.id.textView)
//        val messageTextView1=findViewById<TextView>(R.id.textView1)
//        val messageTextView2=findViewById<TextView>(R.id.textView2)
//        val messageTextView3=findViewById<TextView>(R.id.textView3)


        // Пример запроса к серверу с использованием Retrofit
        // ConnectServer(messageTextView)

        //  val requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), "{\"login\":\"stdf\",\"email\":\"ssdt\",\"password\":\"sdst\"}")

        val requestBody = mapOf(
            "login" to "",
            "email" to "test",
            "password" to "test"
        )

        val request = mapOf(
            "name" to "wow"
        )
        val cat_name = "sport"
        val user_email = "test"
        val new_activity_name="wowhhhhhh"
        //create and send user for backend
        CreateActivity(request,cat_name,user_email,messageTextView)
        //  DeleteActivity(request,cat_name,user_email,messageTextView)
       // ConnectServer(messageTextView)
//        Authorization(requestBody) { result ->
//            Toast.makeText(this, result, Toast.LENGTH_SHORT).show()
//        }
        //  CreateUser(requestBody,this)
        // GetCategory(messageTextView)
       // UpdateActivity(request,cat_name,user_email,new_activity_name,messageTextView)
//        Authorization(requestBody, this) { success ->
////                if (success) {
//             Toast.makeText(this, success, Toast.LENGTH_SHORT).show()
//            val intent = Intent(this, MainActivity::class.java)
//            startActivity(intent)
//                }
//            }

        }

}